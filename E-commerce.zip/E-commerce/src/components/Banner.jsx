import React from "react";
import banner from "../images/Background image.jpg";

const Banner = () => {
  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/50 z-10"></div>
      <img
        src={banner}
        alt="banner"
        className="w-full h-[500px] object-cover"
      />
      <div className="absolute inset-0 flex items-center justify-center z-20">
        <div className="text-center text-white">
          <h1 className="text-5xl font-bold mb-4">Welcome to Our Store</h1>
          <p className="text-xl">Discover amazing products at great prices</p>
        </div>
      </div>
    </div>
  );
};

export default Banner;